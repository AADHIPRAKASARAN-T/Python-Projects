# Trader Performance vs Market Sentiment

Analysis of how Bitcoin market sentiment (Fear/Greed Index) relates to trader behavior
and performance on Hyperliquid — submitted for the Primetrade.ai Data Science/Analytics
Intern Round-0 assignment.

## Contents

```
.
├── notebook.ipynb      # Full analysis: Parts A, B, C + bonus model & clustering
├── README.md           # This file
├── SUMMARY.md           # One-page write-up: methodology, insights, strategy recommendations
├── charts/              # All exported charts (also rendered inline in the notebook)
└── data/
    ├── historical_data.csv     # Hyperliquid trade-level data (provided)
    └── fear_greed_index.csv    # Bitcoin Fear/Greed Index (provided)
```

## Setup & How to Run

1. Clone/download this repo (or folder).
2. Install dependencies:
   ```bash
   pip install pandas numpy matplotlib scipy scikit-learn jupyter
   ```
3. Make sure `historical_data.csv` and `fear_greed_index.csv` are in the `data/` folder
   (already included here — original sources linked in the assignment email).
4. Launch and run the notebook top to bottom:
   ```bash
   jupyter notebook notebook.ipynb
   ```
   or execute non-interactively:
   ```bash
   jupyter nbconvert --to notebook --execute --inplace notebook.ipynb
   ```

The notebook has already been run end-to-end with no errors; all outputs/charts shown
are reproducible from the raw CSVs.

## Data

- **Historical trader data**: 211,224 trade fills, 32 accounts, 246 coins. No missing
  values, no duplicates.
- **Fear/Greed index**: 2,644 daily observations (2018–2025). No missing values, no
  duplicates. The 5-way classification (Extreme Fear/Fear/Neutral/Greed/Extreme Greed)
  is collapsed to 3 buckets (Fear / Neutral / Greed) for cleaner comparison.
- Datasets are aligned on **calendar date** (IST). Only 6 of 211,224 trade rows
  (<0.01%) fell outside Fear/Greed index coverage and were dropped.
- **Note on leverage**: the raw data has no explicit leverage or account-equity field.
  Average trade size (USD) is used throughout as the closest available proxy for
  position-sizing / risk intensity.

## Key Result (see SUMMARY.md for full write-up)

Sentiment reliably shifts trader **behavior** (more trades, larger size, more long-bias
during Fear — all statistically meaningful), but does **not** reliably shift **PnL
outcomes** on its own (differences not statistically significant). Position size and
account-level consistency are the stronger, statistically useful drivers of performance,
and their effect is amplified — not created — by Fear regimes.
