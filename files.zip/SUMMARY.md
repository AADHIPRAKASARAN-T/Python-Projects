# Summary: Trader Performance vs Market Sentiment

## Methodology

**Data.** 211,224 Hyperliquid trade fills across 32 accounts (May 2023–May 2025) were
joined to the Bitcoin Fear/Greed Index on calendar date (IST). Both datasets were clean
(no nulls, no duplicates); only 6 trade rows fell outside index coverage and were
dropped. The 5-way sentiment classification was collapsed into **Fear / Neutral / Greed**
for clearer comparison.

**Metrics.** For each account-day and sentiment-day I computed: trade count, total and
average PnL, win rate (share of fills with realized PnL > 0), average trade size (USD,
used as a leverage/risk-taking proxy since the data has no explicit leverage field),
long/short bias, and a drawdown proxy (average PnL on losing days).

**Segmentation.** Accounts were split into three independent segments using median
splits on lifetime behavior: **position size** (High vs Low), **trading frequency**
(Frequent vs Infrequent), and **consistency** (% of historically profitable days, split
into Consistent winners vs Inconsistent).

**Statistical testing.** Welch's t-test and Mann-Whitney U were used to check whether
Fear-vs-Greed differences in PnL, win rate, and trade count were significant, rather than
relying on chart-reading alone.

## Insights

1. **Sentiment predicts trading activity more reliably than trading profit.** Trade
   frequency is significantly higher on Fear days (p = 0.004), but PnL and win-rate
   differences between Fear and Greed are *not* statistically significant (p > 0.3) —
   the raw average-PnL gap is driven by a few high-volume accounts, not a broad edge.
2. **Position size is the strongest, most consistent performance differentiator** —
   stronger than sentiment itself. High-size accounts outperform low-size accounts in
   every sentiment regime, and the gap is widest on Fear days.
3. **Frequent traders capture more value from Fear regimes**, while infrequent traders
   do comparatively better in calmer Greed conditions — each segment appears to have a
   "home turf" sentiment regime.
4. **Consistency is a durable trait, not a market-mood effect** — consistent-winner
   accounts hold a stable win-rate edge across all three sentiment regimes.
5. **This cohort trades contrarian, not panicked**, during Fear (65% long vs. 51% long
   on Greed days) — opposite of a naive "sell into fear" assumption.

## Strategy Recommendations

**1. Condition size increases on trader segment, not sentiment alone.** Only allow
larger position sizing during Fear regimes for accounts that are already above their own
historical median size AND have a >50% historical profitable-day rate. Since sentiment
alone doesn't reliably lift PnL, but position size does — and the size effect is
amplified during Fear — this targets the one combination with real evidence behind it.

**2. Use sentiment as an activity throttle for proven, frequent traders — not a
blanket call to trade more.** Increase trade frequency allowances during Fear only for
accounts that are already frequent traders with a positive track record (they show a
clear PnL lift on Fear days). Do not push infrequent traders to trade more just because
sentiment shifted; their edge shows up on calmer days, and added activity during Fear
would likely just add cost/noise without demonstrated payoff.

Both rules avoid treating "Fear" as a standalone directional or sizing signal — the
data shows sentiment reliably changes *behavior*, but the *payoff* of that behavior
depends on which trader segment is acting on it.

## Bonus Results

- A Random Forest predicting next-day account profitability from sentiment + behavior
  features reached **AUC ≈ 0.62**. Consistent with the insights above, sentiment was the
  *least* important feature; trade size, today's PnL, and trade count carried most of
  the signal.
- KMeans clustering on lifetime behavior surfaced three trader archetypes: **high-volume
  grinders** (very active, smaller size, highest consistency), **large-position
  moderate traders** (fewer, bigger trades), and a **low-activity, inconsistent** group
  with the weakest results — a natural segmentation to layer the strategy rules above
  onto.

*Full code, charts, and reproducible steps are in `notebook.ipynb`.*
